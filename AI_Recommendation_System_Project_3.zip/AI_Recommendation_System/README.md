# AI Movie Recommendation System — Project 3

## Overview
This project implements a simple AI recommendation system based on user preferences and similarity logic. It accepts user interests, compares them with movie attributes, calculates a similarity score, and displays the most relevant movies.

## Project Requirements Covered
- User input: genre, language, mood, and type
- Preference matching using similarity logic
- Recommended items displayed with similarity scores
- Pattern matching and recommendation concepts

## How the Algorithm Works
Four preference attributes are compared:
1. Genre
2. Language
3. Mood
4. Type

Each matching attribute contributes 25%.
Therefore:

Similarity Score = (Number of Matching Attributes / 4) × 100

Example:
- Genre matches = 1
- Language matches = 1
- Mood matches = 1
- Type matches = 1

Score = (4 / 4) × 100 = 100%

## Requirements
- Python 3.9 or newer
- pandas

## Installation
Open the project folder in VS Code terminal:

```bash
pip install -r requirements.txt
```

## Run
```bash
python main.py
```

## Test
```bash
python test_recommender.py
```

Expected:
```text
All tests passed successfully.
```

## Example
Input:
- Genre: Action
- Language: English
- Mood: Exciting
- Type: Movie

The system calculates scores and ranks movies from highest to lowest similarity.

## Future Improvements
- Add ratings
- Add more user preferences
- Use weighted similarity
- Add a graphical user interface
- Store user history
- Use machine-learning recommendation models
