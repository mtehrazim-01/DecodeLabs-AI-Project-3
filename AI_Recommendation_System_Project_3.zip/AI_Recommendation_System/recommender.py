import pandas as pd

FEATURES = ["genre", "language", "mood", "type"]

def calculate_similarity(user_preferences, movie):
    """Return similarity as a percentage based on matching preference fields."""
    matches = sum(
        str(user_preferences[field]).strip().lower()
        == str(movie[field]).strip().lower()
        for field in FEATURES
    )
    return (matches / len(FEATURES)) * 100

def recommend_movies(user_preferences, data, top_n=5):
    results = data.copy()
    results["similarity_score"] = results.apply(
        lambda movie: calculate_similarity(user_preferences, movie), axis=1
    )
    results = results.sort_values(
        by=["similarity_score", "title"], ascending=[False, True]
    ).head(top_n)
    return results

def get_choices(data, column):
    return sorted(data[column].dropna().astype(str).unique())

def get_user_preferences(data):
    print("\n=== AI MOVIE RECOMMENDATION SYSTEM ===")
    print("Choose your preferences from the available options.\n")

    preferences = {}
    for field in FEATURES:
        choices = get_choices(data, field)
        print(f"{field.title()} options: {', '.join(choices)}")
        while True:
            value = input(f"Enter your preferred {field}: ").strip()
            if value.lower() in [x.lower() for x in choices]:
                # Preserve dataset spelling
                preferences[field] = next(
                    x for x in choices if x.lower() == value.lower()
                )
                break
            print("Invalid choice. Please select one of the listed options.")
    return preferences
