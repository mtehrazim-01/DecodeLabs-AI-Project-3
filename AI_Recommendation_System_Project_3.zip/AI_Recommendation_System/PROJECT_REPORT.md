# ARTIFICIAL INTELLIGENCE — PROJECT 3
# AI RECOMMENDATION LOGIC

## 1. Project Title
AI Movie Recommendation System

## 2. Introduction
The project is a simple recommendation engine that matches a user's preferences with item attributes. It demonstrates the basic recommendation concept using direct similarity logic rather than a complex neural model.

## 3. Objective
The objective is to:
- take user interests as input,
- compare the interests with movie attributes,
- calculate a similarity score,
- rank and display suitable recommendations.

## 4. Input
The system asks the user to select:
- Genre
- Language
- Mood
- Type

## 5. Dataset
The dataset is stored in `movies.csv` and contains movie titles and their attributes.

## 6. Methodology
For every movie, the system compares four attributes with the user's preferences.

If an attribute matches, it contributes one match.

Similarity Score = (Matches / 4) × 100

Possible scores are 0%, 25%, 50%, 75%, and 100%.

The movies are sorted by similarity score in descending order.

## 7. Algorithm
1. Load the movie dataset.
2. Display valid choices.
3. Receive the user's preferences.
4. Compare each preference with every movie.
5. Count matching attributes.
6. Convert the match count to a percentage.
7. Sort movies by score.
8. Display the top five recommendations.

## 8. Technologies
- Python
- Pandas
- CSV dataset
- VS Code

## 9. Testing
The project includes tests for:
- 100% similarity
- partial similarity
- recommendation output

Run:
`python test_recommender.py`

## 10. Result
The system successfully produces ranked movie recommendations based on the user's selected preferences.

## 11. Limitations
This is a rule-based similarity recommender. It does not learn from historical users, ratings, or behavior.

## 12. Future Scope
The system can be extended with:
- weighted attributes,
- user ratings,
- collaborative filtering,
- content embeddings,
- machine learning,
- a web interface.

## 13. Conclusion
This project demonstrates the fundamental logic of an AI recommendation system: converting user preferences into a structured profile, comparing that profile with item attributes, and ranking the closest matches. It fulfills the core Project 3 recommendation requirements.
