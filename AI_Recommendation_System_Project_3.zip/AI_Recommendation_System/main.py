import pandas as pd
from recommender import get_user_preferences, recommend_movies

def main():
    try:
        data = pd.read_csv("movies.csv")
    except FileNotFoundError:
        print("Error: movies.csv was not found.")
        return

    preferences = get_user_preferences(data)

    print("\nYour preferences:")
    for key, value in preferences.items():
        print(f"  {key.title()}: {value}")

    print("\nCalculating similarity...")
    recommendations = recommend_movies(preferences, data, top_n=5)

    print("\n=== RECOMMENDED MOVIES ===")
    for number, (_, movie) in enumerate(recommendations.iterrows(), start=1):
        print(
            f"{number}. {movie['title']} | "
            f"{movie['genre']} | {movie['language']} | "
            f"{movie['mood']} | Similarity: {movie['similarity_score']:.0f}%"
        )

if __name__ == "__main__":
    main()
