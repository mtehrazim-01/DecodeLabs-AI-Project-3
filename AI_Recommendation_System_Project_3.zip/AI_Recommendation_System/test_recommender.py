import pandas as pd
from recommender import calculate_similarity, recommend_movies

def test_perfect_match():
    data = pd.read_csv("movies.csv")
    user = {
        "genre": "Sci-Fi",
        "language": "English",
        "mood": "Exciting",
        "type": "Movie"
    }
    score = calculate_similarity(user, data.iloc[0])
    assert score == 100.0

def test_no_match():
    data = pd.read_csv("movies.csv")
    user = {
        "genre": "Drama",
        "language": "Korean",
        "mood": "Scary",
        "type": "Movie"
    }
    score = calculate_similarity(user, data.iloc[0])
    assert score == 25.0

def test_recommendations_returned():
    data = pd.read_csv("movies.csv")
    user = {
        "genre": "Action",
        "language": "English",
        "mood": "Exciting",
        "type": "Movie"
    }
    result = recommend_movies(user, data, top_n=3)
    assert len(result) == 3
    assert "similarity_score" in result.columns

if __name__ == "__main__":
    test_perfect_match()
    test_no_match()
    test_recommendations_returned()
    print("All tests passed successfully.")
